These are actually the binaries off HDP 2.3.0; they should be interchangeble with the ASF 2.7.1 release

(usual disclaimers etc: if you want the artifacts direct you can download the whole install from hortonworks.com. 

This is just what ended up in my hdp/bin dir after the installation -though I have deleted the pdb files.
